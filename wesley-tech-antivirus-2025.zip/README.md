# Wesley Tech - Os 7 Melhores Antivírus de 2025

Este é o site oficial do artigo **Os 7 Melhores Antivírus de 2025 (Grátis e Pagos)** publicado no projeto **Wesley Tech**.

## Estrutura
- `index.html` → Página principal
- `style.css` → Estilos
- `README.md` → Documentação

## Publicação
Este site está pronto para ser publicado no **Netlify**.  
Basta fazer upload da pasta inteira (ZIP) no painel do Netlify.
